﻿// Controllers/TodoController.cs
using Microsoft.AspNetCore.Mvc;
using TodoListAPI.Models;
using System.Collections.Generic;
using System.Linq;

namespace TodoListAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TodoController : ControllerBase
    {
        private static List<TodoItem> todos = new List<TodoItem>();

        [HttpGet]
        public ActionResult<IEnumerable<TodoItem>> Get()
        {
            return Ok(todos);
        }

        [HttpGet("{id}")]
        public ActionResult<TodoItem> Get(int id)
        {
            var todo = todos.FirstOrDefault(t => t.Id == id);
            if (todo == null)
            {
                return NotFound();
            }
            return Ok(todo);
        }

        [HttpPost]
        public ActionResult<TodoItem> Create(TodoItem todo)
        {
            if (todo == null)
            {
                return BadRequest("Todo item cannot be null.");
            }

            // Assign a unique ID
            todo.Id = todos.Count + 1; // Ensure unique ID
            todos.Add(todo);

            // Return the created item using CreatedAtAction
            return CreatedAtAction(nameof(Get), new { id = todo.Id }, todo);
        }

        [HttpPut("{id}")]
        public ActionResult Update(int id, TodoItem todo)
        {
            if (todo == null)
            {
                return BadRequest("Todo item cannot be null.");
            }

            var existingTodo = todos.FirstOrDefault(t => t.Id == id);
            if (existingTodo == null)
            {
                return NotFound();
            }

            existingTodo.Name = todo.Name;
            existingTodo.IsCompleted = todo.IsCompleted;

            // Return NoContent to indicate the update was successful
            return NoContent();
        }

        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var todo = todos.FirstOrDefault(t => t.Id == id);
            if (todo == null)
            {
                return NotFound();
            }

            todos.Remove(todo);
            return NoContent();
        }
    }
}
