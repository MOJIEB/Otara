﻿// TodoControllerTests.cs
using Microsoft.AspNetCore.Mvc;
using NUnit.Framework;
using TodoListAPI.Controllers;
using TodoListAPI.Models;
using System.Collections.Generic;
using System.Linq;

namespace TodoListTests
{
    public class TodoControllerTests
    {
        private TodoController _controller;

        [SetUp]
        public void SetUp()
        {
            _controller = new TodoController();
            // Reset the static todos list before each test
            typeof(TodoController).GetField("todos", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic).SetValue(null, new List<TodoItem>());
        }

        [Test]
        public void Get_ShouldReturnAllTodos()
        {
            // Arrange
            var todo1 = new TodoItem { Name = "Test Todo 1", IsCompleted = false };
            var todo2 = new TodoItem { Name = "Test Todo 2", IsCompleted = true };

            // Act
            _controller.Create(todo1);
            _controller.Create(todo2);
            var result = _controller.Get();

            // Assert
            var okResult = result.Result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.IsInstanceOf<IEnumerable<TodoItem>>(okResult.Value);
            var todos = okResult.Value as IEnumerable<TodoItem>;
            Assert.AreEqual(2, todos.Count());
        }

        [Test]
        public void Get_ShouldReturnCorrectTodo()
        {
            // Arrange
            var todo = new TodoItem { Name = "Test Todo", IsCompleted = false };
            _controller.Create(todo);

            // Act
            var result = _controller.Get(1);

            // Assert
            var okResult = result.Result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.IsInstanceOf<TodoItem>(okResult.Value);
            var returnedTodo = okResult.Value as TodoItem;
            Assert.AreEqual("Test Todo", returnedTodo.Name);
        }

        [Test]
        public void Create_ShouldReturnCreatedTodo()
        {
            // Arrange
            var todo = new TodoItem { Name = "New Todo", IsCompleted = false };

            // Act
            var result = _controller.Create(todo);

            // Assert
            var createdResult = result.Result as CreatedAtActionResult;
            Assert.IsNotNull(createdResult);
            Assert.IsInstanceOf<TodoItem>(createdResult.Value);
            var createdTodo = createdResult.Value as TodoItem;
            Assert.AreEqual("New Todo", createdTodo.Name);
        }

        [Test]
        public void Update_ShouldReturnNoContent()
        {
            // Arrange
            var todo = new TodoItem { Name = "Test Todo", IsCompleted = false };
            _controller.Create(todo);
            var updatedTodo = new TodoItem { Name = "Updated Todo", IsCompleted = true };

            // Act
            var result = _controller.Update(1, updatedTodo);

            // Assert
            Assert.IsInstanceOf<NoContentResult>(result);
        }

        [Test]
        public void Delete_ShouldReturnNoContent()
        {
            // Arrange
            var todo = new TodoItem { Name = "Test Todo", IsCompleted = false };
            _controller.Create(todo);

            // Act
            var result = _controller.Delete(1);

            // Assert
            Assert.IsInstanceOf<NoContentResult>(result);
        }

        [Test]
        public void Delete_ShouldReturnNotFound()
        {
            // Act
            var result = _controller.Delete(99); // ID that doesn't exist

            // Assert
            Assert.IsInstanceOf<NotFoundResult>(result);
        }
    }
}
